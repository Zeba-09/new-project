import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";
import { getStorage } from "firebase/storage";

// Firebase configuration with fallback values
const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyAk6X-YqPa5HDxWNGfnMsepNNqv94V9HCM",
  authDomain: import.meta.env.VITE_FIREBASE_AUTH_DOMAIN || "goodminds-81188.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "goodminds-81188",
  storageBucket: import.meta.env.VITE_FIREBASE_STORAGE_BUCKET || "goodminds-81188.firebasestorage.app",
  messagingSenderId: import.meta.env.VITE_FIREBASE_MESSAGING_SENDER_ID || "407768731367",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:407768731367:web:a58dc608a124e1ad749c42",
  measurementId: import.meta.env.VITE_FIREBASE_MEASUREMENT_ID || "G-R009DKH7R6",
};

let app;
let auth;
let provider;
let db;
let analytics;
let storage;
let isFirebaseInitialized = false;

try {
  // Initialize Firebase
  app = initializeApp(firebaseConfig);
  auth = getAuth(app);
  provider = new GoogleAuthProvider();
  
  // Configure Google Auth Provider
  provider.setCustomParameters({
    prompt: 'select_account'
  });
  
  db = getFirestore(app);
  
  // Only initialize analytics in production and when available
  if (typeof window !== 'undefined' && import.meta.env.PROD) {
    try {
      analytics = getAnalytics(app);
    } catch (error) {
      console.warn('Analytics initialization failed:', error);
    }
  }
  
  storage = getStorage(app);
  isFirebaseInitialized = true;
  
  console.log('Firebase initialized successfully');
} catch (error) {
  console.error('Firebase initialization error:', error);
  isFirebaseInitialized = false;
  
  // Create mock objects for demo mode when Firebase fails
  auth = {
    currentUser: null,
    onAuthStateChanged: (callback: any) => {
      // Call callback with null user immediately for demo mode
      setTimeout(() => callback(null), 100);
      return () => {}; // Return unsubscribe function
    },
    signOut: () => Promise.resolve(),
    signInWithEmailAndPassword: () => Promise.reject(new Error('Demo mode - Firebase not configured')),
    createUserWithEmailAndPassword: () => Promise.reject(new Error('Demo mode - Firebase not configured')),
    sendPasswordResetEmail: () => Promise.reject(new Error('Demo mode - Firebase not configured')),
  } as any;
  
  provider = {
    setCustomParameters: () => {},
  } as any;
  
  db = {
    collection: () => ({}),
    doc: () => ({}),
  } as any;
  
  storage = {} as any;
}

// Export initialization status
export { app, auth, provider, db, analytics, storage, isFirebaseInitialized };