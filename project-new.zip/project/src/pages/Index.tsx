import React, { useState, useEffect } from 'react';
import Landing from '@/components/Landing';
import Dashboard from '@/components/Dashboard';
import AuthModal from '@/components/AuthModal';
import SplashScreen from '@/components/SplashScreen';
import { auth, db, isFirebaseInitialized } from '@/lib/firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

const Index = () => {
  const [showSplash, setShowSplash] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [demoMode, setDemoMode] = useState(false);
  const { toast } = useToast();

  // Handle splash screen
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 3000); // Show splash for 3 seconds
    return () => clearTimeout(timer);
  }, []);

  // Save user data to Firestore
  const saveUserToFirestore = async (user: any) => {
    try {
      if (isFirebaseInitialized && db && typeof setDoc === 'function') {
        await setDoc(doc(db, `users/${user.uid}`), {
          displayName: user.displayName || user.email?.split('@')[0] || 'User',
          email: user.email || '',
          photoURL: user.photoURL || '',
          lastLogin: new Date().toISOString(),
          createdAt: new Date().toISOString(),
        }, { merge: true });
      }
    } catch (error) {
      console.error('Error saving user to Firestore:', error);
    }
  };

  // Listen for authentication state changes
  useEffect(() => {
    try {
      if (isFirebaseInitialized && auth && typeof auth.onAuthStateChanged === 'function') {
        const unsubscribe = onAuthStateChanged(auth, async (user) => {
          setIsAuthenticated(!!user);
          setLoading(false);
          
          if (user) {
            // Save user data to Firestore
            await saveUserToFirestore(user);
            
            if (!showSplash) {
              setShowAuth(false);
            }
          }
        });

        return () => unsubscribe();
      } else {
        // Firebase not properly initialized, enable demo mode
        console.warn('Firebase authentication not available, enabling demo mode');
        setLoading(false);
        setDemoMode(true);
      }
    } catch (error) {
      console.error('Auth initialization error:', error);
      setLoading(false);
      setDemoMode(true);
    }
  }, [showSplash]);

  const handleGetStarted = () => {
    if (demoMode || !isFirebaseInitialized) {
      // In demo mode, just show the dashboard
      setIsAuthenticated(true);
      toast({
        title: "Demo Mode",
        description: "Welcome to GoodMind! You're viewing the demo version with sample data.",
      });
    } else {
      setShowAuth(true);
    }
  };

  const handleAuthSuccess = () => {
    setShowAuth(false);
    setIsAuthenticated(true);
    const user = auth?.currentUser;
    toast({
      title: "Welcome to GoodMind!",
      description: `Hello ${user?.displayName || 'there'}! Your wellness journey begins now.`,
    });
  };

  const handleLogout = async () => {
    try {
      if (isFirebaseInitialized && auth && typeof signOut === 'function') {
        await signOut(auth);
      }
      setIsAuthenticated(false);
      setShowAuth(false);
      toast({
        title: "Signed Out",
        description: "Take care! We'll be here when you're ready to continue your wellness journey.",
      });
    } catch (error) {
      console.error('Error signing out:', error);
      // Force logout even if Firebase fails
      setIsAuthenticated(false);
      setShowAuth(false);
      toast({
        title: "Signed Out",
        description: "You have been signed out.",
      });
    }
  };

  // Show splash screen
  if (showSplash) {
    return <SplashScreen />;
  }

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-50 via-blue-50 to-pink-50 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-300">Loading your wellness sanctuary...</p>
        </div>
      </div>
    );
  }

  // Show dashboard if authenticated
  if (isAuthenticated) {
    return <Dashboard onLogout={handleLogout} />;
  }

  // Show landing page with auth modal
  return (
    <>
      <Landing onGetStarted={handleGetStarted} />
      {!demoMode && isFirebaseInitialized && (
        <AuthModal 
          isOpen={showAuth}
          onClose={() => setShowAuth(false)}
          onAuthSuccess={handleAuthSuccess}
        />
      )}
      {(demoMode || !isFirebaseInitialized) && (
        <div className="fixed bottom-4 right-4 bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded-lg shadow-lg max-w-sm z-50">
          <p className="text-sm">
            <strong>Demo Mode:</strong> Firebase not configured. All features are available for demonstration with sample data.
          </p>
        </div>
      )}
    </>
  );
};

export default Index;