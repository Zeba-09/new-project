import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Phone, MessageCircle, Calendar, Volume2, ExternalLink } from 'lucide-react';
import { auth, db } from '../lib/firebase';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

const VoiceAssistant = () => {
  const [recentSessions, setRecentSessions] = useState([]);
  const { toast } = useToast();
  const user = auth.currentUser;

  // Fetch recent sessions
  useEffect(() => {
    if (!user) return;
    
    const q = query(
      collection(db, `users/${user.uid}/taraSessions`), 
      orderBy('startTime', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const sessions = [];
      snapshot.forEach(doc => {
        sessions.push({ id: doc.id, ...doc.data() });
      });
      setRecentSessions(sessions.slice(0, 5));
    });

    return () => unsubscribe();
  }, [user]);

  const handleBookAppointment = () => {
    window.open('https://calendly.com/goodmind/appointment1?month=2025-07', '_blank');
  };

  const handleCallTara = () => {
    // Redirect to the specified TARA URL
    window.open('https://tara-mobile-options-28kx.vercel.app/call-tara', '_blank');
  };

  return (
    <div className="space-y-8 animate-slide-up-smooth">
      <div>
        <h1 className="text-3xl font-bold text-gray-800 mb-2">Call to TARA</h1>
        <p className="text-gray-600">
          Connect with TARA, your AI-powered mental health companion. 
          She's here to listen, support, and guide you through your academic and personal challenges.
        </p>
      </div>

      {/* TARA Introduction */}
      <Card className="card-modern">
        <CardContent className="p-8 text-center">
          <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-br from-green-500 via-teal-500 to-blue-500 rounded-full flex items-center justify-center animate-pulse-soft relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-green-400 to-teal-400 rounded-full animate-pulse"></div>
            <div className="relative w-28 h-28 bg-white rounded-full flex items-center justify-center">
              <span className="text-4xl">🌸</span>
            </div>
            <div className="absolute -top-2 -right-2 w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">✓</span>
            </div>
          </div>
          
          <h2 className="text-2xl font-bold text-gray-800 mb-4">Meet TARA</h2>
          <p className="text-gray-600 mb-8 max-w-2xl mx-auto leading-relaxed">
            TARA is your compassionate AI mental health specialist, available 24/7 to provide 
            support, guidance, and a listening ear specifically for student challenges. She understands 
            academic stress, social pressures, and the unique mental health needs of students.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
            <div className="bg-gradient-to-r from-green-100 to-teal-100 p-4 rounded-2xl">
              <MessageCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-800 mb-1">AI Powered</h3>
              <p className="text-sm text-gray-600">Advanced AI conversation with natural voice synthesis</p>
            </div>
            <div className="bg-gradient-to-r from-teal-100 to-blue-100 p-4 rounded-2xl">
              <Phone className="w-8 h-8 text-teal-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-800 mb-1">24/7 Available</h3>
              <p className="text-sm text-gray-600">Always here when you need support, day or night</p>
            </div>
            <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-4 rounded-2xl">
              <Volume2 className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <h3 className="font-semibold text-gray-800 mb-1">Confidential & Safe</h3>
              <p className="text-sm text-gray-600">Private conversations in a judgment-free space</p>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              onClick={handleCallTara}
              className="btn-goodmind text-lg px-12 py-6 rounded-2xl transform hover:scale-105 transition-all duration-300 shadow-xl"
            >
              <Phone className="w-6 h-6 mr-3" />
              Start Session with TARA
            </Button>
            
            <Button 
              onClick={handleBookAppointment}
              variant="outline"
              className="border-2 border-green-600 text-green-600 hover:bg-green-600 hover:text-white text-lg px-12 py-6 rounded-2xl transform hover:scale-105 transition-all duration-300"
            >
              <Calendar className="w-6 h-6 mr-3" />
              Book an Appointment
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Sessions */}
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="text-xl text-gray-800">Recent Sessions</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentSessions.length === 0 ? (
              <div className="text-center py-8">
                <Phone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-500">No sessions yet. Start your first conversation with TARA!</p>
              </div>
            ) : (
              recentSessions.map((session, index) => (
                <div key={session.id || index} className="flex items-center justify-between p-4 bg-white/50 rounded-2xl hover:bg-white/70 transition-colors">
                  <div>
                    <div className="font-medium text-gray-800">{session.topic || 'Student wellness conversation'}</div>
                    <div className="text-sm text-gray-600">
                      {session.startTime ? new Date(session.startTime.toDate()).toLocaleString() : 'Recent'} 
                      {session.duration && ` • ${session.duration}`}
                      <span className="ml-2 px-2 py-1 bg-green-100 text-green-700 text-xs rounded-full">
                        TARA
                      </span>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="rounded-xl">View Notes</Button>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tips for Students */}
      <Card className="card-modern">
        <CardHeader>
          <CardTitle className="text-xl text-gray-800">💡 Tips for Your Session</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gradient-to-r from-green-100 to-teal-100 p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-800 mb-2">🎧 Find a Quiet Study Space</h4>
              <p className="text-gray-700 text-sm">Choose a comfortable, private environment where you feel safe to express yourself about academic and personal challenges.</p>
            </div>
            <div className="bg-gradient-to-r from-teal-100 to-blue-100 p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-800 mb-2">💭 Share Your Academic Stress</h4>
              <p className="text-gray-700 text-sm">TARA understands student life. Feel free to discuss exam anxiety, social pressures, or any academic concerns.</p>
            </div>
            <div className="bg-gradient-to-r from-blue-100 to-purple-100 p-4 rounded-2xl">
              <h4 className="font-semibent text-gray-800 mb-2">⏰ No Time Pressure</h4>
              <p className="text-gray-700 text-sm">Take your time. TARA is available 24/7, so you can have sessions whenever you need support.</p>
            </div>
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-4 rounded-2xl">
              <h4 className="font-semibold text-gray-800 mb-2">🤝 Remember: You're Not Alone</h4>
              <p className="text-gray-700 text-sm">Many students face similar challenges. TARA is here to remind you that seeking help is a sign of strength.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default VoiceAssistant;