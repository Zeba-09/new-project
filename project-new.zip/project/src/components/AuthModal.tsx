import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Brain, Mail, Lock, Eye, EyeOff, User, Phone, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { auth, db, isFirebaseInitialized } from '../lib/firebase';
import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword,
  sendPasswordResetEmail,
  updateProfile
} from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAuthSuccess: () => void;
}

const AuthModal = ({ isOpen, onClose, onAuthSuccess }: AuthModalProps) => {
  const [isLogin, setIsLogin] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    age: '',
    contactNumber: '',
    password: '',
    confirmPassword: ''
  });
  const [loading, setLoading] = useState(false);
  const [showForgotPassword, setShowForgotPassword] = useState(false);
  const { toast } = useToast();

  if (!isOpen) return null;

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = () => {
    if (!formData.email || !formData.password) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return false;
    }

    if (!isLogin) {
      if (!formData.name || !formData.age || !formData.contactNumber) {
        toast({
          title: "Missing Information",
          description: "Please fill in all required fields for registration.",
          variant: "destructive",
        });
        return false;
      }

      if (formData.password !== formData.confirmPassword) {
        toast({
          title: "Password Mismatch",
          description: "Passwords do not match.",
          variant: "destructive",
        });
        return false;
      }

      if (parseInt(formData.age) < 13 || parseInt(formData.age) > 100) {
        toast({
          title: "Invalid Age",
          description: "Please enter a valid age between 13 and 100.",
          variant: "destructive",
        });
        return false;
      }
    }

    if (formData.password.length < 6) {
      toast({
        title: "Weak Password",
        description: "Password must be at least 6 characters long.",
        variant: "destructive",
      });
      return false;
    }

    return true;
  };

  const saveUserToFirestore = async (user: any, additionalData: any = {}) => {
    try {
      if (isFirebaseInitialized && db && typeof setDoc === 'function') {
        await setDoc(doc(db, `users/${user.uid}`), {
          displayName: user.displayName || additionalData.displayName || '',
          email: user.email || '',
          photoURL: user.photoURL || '',
          age: additionalData.age || '',
          contactNumber: additionalData.contactNumber || '',
          createdAt: new Date().toISOString(),
          lastLogin: new Date().toISOString(),
          ...additionalData
        }, { merge: true });
      }
    } catch (error) {
      console.error('Error saving user to Firestore:', error);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    // Check if Firebase is properly configured
    if (!isFirebaseInitialized) {
      toast({
        title: "Service Unavailable",
        description: "Authentication service is currently unavailable. Please try the demo mode instead.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    
    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, formData.email, formData.password);
        toast({
          title: "Welcome back!",
          description: "You've been successfully signed in.",
        });
      } else {
        // Create user account
        const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
        const user = userCredential.user;
        
        // Update user profile with display name
        if (user.updateProfile) {
          await updateProfile(user, {
            displayName: formData.name
          });
        }

        // Save additional user data to Firestore
        await saveUserToFirestore(user, {
          displayName: formData.name,
          age: formData.age,
          contactNumber: formData.contactNumber
        });

        toast({
          title: "Account created!",
          description: `Welcome to GoodMind, ${formData.name}! Your wellness journey begins now.`,
        });
      }
      onAuthSuccess();
    } catch (error: any) {
      console.error("Email auth error:", error);
      let errorMessage = "Authentication failed. Please try again.";
      
      // Handle specific Firebase errors
      switch (error.code) {
        case 'auth/user-not-found':
          errorMessage = "No account found with this email address.";
          break;
        case 'auth/wrong-password':
          errorMessage = "Incorrect password. Please try again.";
          break;
        case 'auth/email-already-in-use':
          errorMessage = "An account with this email already exists.";
          break;
        case 'auth/invalid-email':
          errorMessage = "Please enter a valid email address.";
          break;
        case 'auth/weak-password':
          errorMessage = "Password is too weak. Please choose a stronger password.";
          break;
        case 'auth/too-many-requests':
          errorMessage = "Too many failed attempts. Please try again later.";
          break;
        case 'auth/network-request-failed':
          errorMessage = "Network error. Please check your connection and try again.";
          break;
        case 'auth/invalid-credential':
          errorMessage = "Invalid credentials. Please check your email and password.";
          break;
        default:
          // Check if it's a configuration error
          if (error.message.includes('not available') || error.message.includes('not configured')) {
            errorMessage = "Authentication service is temporarily unavailable. Please try the demo mode.";
          } else {
            errorMessage = error.message || "Authentication failed. Please try again.";
          }
      }
      
      toast({
        title: "Authentication Error",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async () => {
    if (!formData.email) {
      toast({
        title: "Email Required",
        description: "Please enter your email address first.",
        variant: "destructive",
      });
      return;
    }

    if (!isFirebaseInitialized) {
      toast({
        title: "Service Unavailable",
        description: "Password reset service is currently unavailable.",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      await sendPasswordResetEmail(auth, formData.email);
      toast({
        title: "Reset Email Sent",
        description: "Check your email for password reset instructions.",
      });
      setShowForgotPassword(false);
    } catch (error: any) {
      console.error("Password reset error:", error);
      toast({
        title: "Reset Failed",
        description: "Failed to send reset email. Please check your email address or try again later.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md glass-modern border-0 shadow-2xl animate-scale-in-smooth">
        <CardHeader className="text-center space-y-4">
          <div className="w-16 h-16 mx-auto bg-gradient-to-br from-green-500 to-teal-500 rounded-2xl flex items-center justify-center animate-float-gentle">
            <Brain className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gray-800">
            {showForgotPassword ? 'Reset Password' : (isLogin ? 'Welcome Back' : 'Join GoodMind')}
          </CardTitle>
          <p className="text-gray-600 dark:text-gray-300">
            {showForgotPassword 
              ? 'Enter your email to receive reset instructions'
              : (isLogin ? 'Continue your wellness journey' : 'Start your mental wellness journey')
            }
          </p>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Firebase Status Warning */}
          {!isFirebaseInitialized && (
            <div className="bg-amber-50 border border-amber-200 rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-2 text-amber-800">
                <AlertCircle className="w-4 h-4" />
                <span className="font-medium text-sm">Service Notice</span>
              </div>
              <div className="text-sm text-amber-700">
                <p>Authentication service is currently unavailable. You can still explore GoodMind in demo mode by clicking "Begin Your Journey" on the main page.</p>
              </div>
            </div>
          )}

          {!showForgotPassword ? (
            <>
              {/* Email/Password Form */}
              <form onSubmit={handleEmailAuth} className="space-y-4">
                {!isLogin && (
                  <>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="text"
                        placeholder="Full Name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        className="pl-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                        required={!isLogin}
                      />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div className="relative">
                        <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          type="number"
                          placeholder="Age"
                          value={formData.age}
                          onChange={(e) => handleInputChange('age', e.target.value)}
                          className="pl-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                          required={!isLogin}
                          min="13"
                          max="100"
                        />
                      </div>
                      <div className="relative">
                        <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                        <Input
                          type="tel"
                          placeholder="Contact Number"
                          value={formData.contactNumber}
                          onChange={(e) => handleInputChange('contactNumber', e.target.value)}
                          className="pl-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                          required={!isLogin}
                        />
                      </div>
                    </div>
                  </>
                )}

                <div className="relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="email"
                    placeholder="Enter your email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="pl-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                    required
                  />
                </div>

                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    placeholder="Enter your password"
                    value={formData.password}
                    onChange={(e) => handleInputChange('password', e.target.value)}
                    className="pl-10 pr-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>

                {!isLogin && (
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <Input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Confirm your password"
                      value={formData.confirmPassword}
                      onChange={(e) => handleInputChange('confirmPassword', e.target.value)}
                      className="pl-10 pr-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                      required={!isLogin}
                    />
                  </div>
                )}

                {isLogin && (
                  <div className="text-right">
                    <button
                      type="button"
                      onClick={() => setShowForgotPassword(true)}
                      className="text-sm text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300"
                    >
                      Forgot password?
                    </button>
                  </div>
                )}

                <Button
                  type="submit"
                  disabled={loading || !isFirebaseInitialized}
                  className="w-full py-6 btn-goodmind"
                >
                  {loading ? 'Please wait...' : (isLogin ? 'Sign In' : 'Create Account')}
                </Button>
              </form>

              {/* Toggle Login/Register */}
              <div className="text-center">
                <button
                  onClick={() => setIsLogin(!isLogin)}
                  className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 font-medium"
                >
                  {isLogin ? "Don't have an account? Sign Up" : "Already have an account? Sign In"}
                </button>
              </div>
            </>
          ) : (
            /* Forgot Password Form */
            <div className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  className="pl-10 py-6 border-2 focus:border-green-300 dark:focus:border-green-600 rounded-2xl"
                  required
                />
              </div>

              <Button
                onClick={handleForgotPassword}
                disabled={loading || !isFirebaseInitialized}
                className="w-full py-6 btn-goodmind"
              >
                {loading ? 'Sending...' : 'Send Reset Email'}
              </Button>

              <div className="text-center">
                <button
                  onClick={() => setShowForgotPassword(false)}
                  className="text-green-600 hover:text-green-700 dark:text-green-400 dark:hover:text-green-300 font-medium"
                >
                  Back to Sign In
                </button>
              </div>
            </div>
          )}

          {/* Close button */}
          <Button
            variant="ghost"
            onClick={onClose}
            className="w-full mt-4 rounded-2xl"
          >
            Cancel
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};

export default AuthModal;