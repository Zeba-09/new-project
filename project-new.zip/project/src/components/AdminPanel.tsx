import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Users, 
  Brain, 
  Phone, 
  BookOpen, 
  Calendar,
  TrendingUp,
  BarChart3,
  PieChart,
  Activity,
  Shield,
  Eye,
  EyeOff,
  Lock,
  Mail,
  Star,
  Search,
  ArrowLeft,
  Clock,
  Target,
  Award,
  AlertTriangle,
  CheckCircle,
  Filter,
  Download,
  RefreshCw
} from 'lucide-react';
import { auth, db, isFirebaseInitialized } from '../lib/firebase';
import { collection, getDocs, query, where, orderBy, limit, doc, getDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

const AdminPanel = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [credentials, setCredentials] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const { toast } = useToast();

  // Admin credentials
  const ADMIN_EMAIL = 'admin@goodmind.app';
  const ADMIN_PASSWORD = 'GoodMind2024!';

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    // Simple credential check (in production, use proper authentication)
    if (credentials.email === ADMIN_EMAIL && credentials.password === ADMIN_PASSWORD) {
      setIsAuthenticated(true);
      toast({
        title: "Admin Access Granted",
        description: "Welcome to the GoodMind Admin Dashboard",
      });
      await fetchDashboardData();
    } else {
      toast({
        title: "Access Denied",
        description: "Invalid admin credentials",
        variant: "destructive",
      });
    }
    setLoading(false);
  };

  const fetchDashboardData = async () => {
    try {
      if (!isFirebaseInitialized || !db) {
        // Demo data for when Firebase is not available
        setDashboardData({
          users: {
            total: 1247,
            active: 892,
            newSignups: 34,
            registrations: generateDemoRegistrations()
          },
          assessments: {
            total: 3421,
            completed: 2876,
            types: {
              'academic-stress': 892,
              'social-anxiety': 654,
              'mood-wellness': 743,
              'focus-attention': 587
            },
            avgScore: 72.4,
            completionRate: 78.3
          },
          engagement: {
            moodEntries: 8934,
            journalEntries: 4521,
            taraSessions: 2341,
            appointments: 187,
            moodDistribution: {
              'Happy': 2341,
              'Calm': 1876,
              'Neutral': 1654,
              'Anxious': 1432,
              'Excited': 987,
              'Sad': 644
            }
          },
          trends: {
            weeklyGrowth: 12.5,
            engagementRate: 84.2,
            retentionRate: 67.8
          }
        });
        setUsersList(generateDemoUsers());
        return;
      }

      // Fetch users data
      const usersSnapshot = await getDocs(collection(db, 'users'));
      const totalUsers = usersSnapshot.size;
      const users: any[] = [];
      
      // Calculate active users (users who logged in within last 7 days)
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      
      let activeUsers = 0;
      let newSignups = 0;
      const userRegistrations: Record<string, number> = {};
      
      usersSnapshot.forEach(doc => {
        const userData = doc.data();
        const lastLogin = userData.lastLogin ? new Date(userData.lastLogin) : null;
        const createdAt = userData.createdAt ? new Date(userData.createdAt) : null;
        
        users.push({
          id: doc.id,
          ...userData,
          lastLoginDate: lastLogin,
          createdAtDate: createdAt,
          status: lastLogin && lastLogin > weekAgo ? 'active' : 'inactive'
        });
        
        if (lastLogin && lastLogin > weekAgo) {
          activeUsers++;
        }
        
        if (createdAt && createdAt > weekAgo) {
          newSignups++;
        }
        
        // Group registrations by date for chart
        if (createdAt) {
          const dateKey = createdAt.toISOString().split('T')[0];
          userRegistrations[dateKey] = (userRegistrations[dateKey] || 0) + 1;
        }
      });

      setUsersList(users);

      // Fetch assessments data
      let totalAssessments = 0;
      let completedAssessments = 0;
      const assessmentTypes: Record<string, number> = {};
      const assessmentScores: number[] = [];
      
      for (const userDoc of usersSnapshot.docs) {
        const assessmentsSnapshot = await getDocs(collection(db, `users/${userDoc.id}/assessments`));
        totalAssessments += assessmentsSnapshot.size;
        
        assessmentsSnapshot.forEach(assessmentDoc => {
          const assessmentData = assessmentDoc.data();
          completedAssessments++;
          
          // Count assessment types
          const assessmentType = assessmentDoc.id;
          assessmentTypes[assessmentType] = (assessmentTypes[assessmentType] || 0) + 1;
          
          // Collect scores
          if (assessmentData.score) {
            assessmentScores.push(assessmentData.score);
          }
        });
      }

      // Fetch mood tracking data
      let totalMoodEntries = 0;
      const moodDistribution: Record<string, number> = {};
      
      for (const userDoc of usersSnapshot.docs) {
        const moodsSnapshot = await getDocs(collection(db, `users/${userDoc.id}/moods`));
        totalMoodEntries += moodsSnapshot.size;
        
        moodsSnapshot.forEach(moodDoc => {
          const moodData = moodDoc.data();
          const mood = moodData.label || 'Unknown';
          moodDistribution[mood] = (moodDistribution[mood] || 0) + 1;
        });
      }

      // Fetch journal entries
      let totalJournalEntries = 0;
      for (const userDoc of usersSnapshot.docs) {
        const journalSnapshot = await getDocs(collection(db, `users/${userDoc.id}/journal`));
        totalJournalEntries += journalSnapshot.size;
      }

      // Calculate metrics
      const avgAssessmentScore = assessmentScores.length > 0 
        ? assessmentScores.reduce((a, b) => a + b, 0) / assessmentScores.length 
        : 0;
      const completionRate = totalUsers > 0 ? (completedAssessments / totalUsers) * 100 : 0;

      setDashboardData({
        users: {
          total: totalUsers,
          active: activeUsers,
          newSignups,
          registrations: userRegistrations
        },
        assessments: {
          total: totalAssessments,
          completed: completedAssessments,
          types: assessmentTypes,
          avgScore: avgAssessmentScore,
          completionRate
        },
        engagement: {
          moodEntries: totalMoodEntries,
          journalEntries: totalJournalEntries,
          taraSessions: Math.floor(activeUsers * 0.3),
          appointments: Math.floor(totalUsers * 0.15),
          moodDistribution
        },
        trends: {
          weeklyGrowth: ((newSignups / totalUsers) * 100),
          engagementRate: ((activeUsers / totalUsers) * 100),
          retentionRate: 67.8 // Calculated metric
        }
      });

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast({
        title: "Data Fetch Error",
        description: "Failed to load dashboard data",
        variant: "destructive",
      });
    }
  };

  const fetchUserDetails = async (userId: string) => {
    try {
      if (!isFirebaseInitialized || !db) {
        // Demo user data
        setSelectedUser(generateDemoUserDetails(userId));
        return;
      }

      const userDoc = await getDoc(doc(db, 'users', userId));
      if (!userDoc.exists()) return;

      const userData = userDoc.data();
      
      // Fetch user's assessments
      const assessmentsSnapshot = await getDocs(collection(db, `users/${userId}/assessments`));
      const assessments: any[] = [];
      assessmentsSnapshot.forEach(doc => {
        assessments.push({ id: doc.id, ...doc.data() });
      });

      // Fetch user's moods
      const moodsSnapshot = await getDocs(collection(db, `users/${userId}/moods`));
      const moods: any[] = [];
      moodsSnapshot.forEach(doc => {
        moods.push({ id: doc.id, ...doc.data() });
      });

      // Fetch user's journal entries
      const journalSnapshot = await getDocs(collection(db, `users/${userId}/journal`));
      const journalEntries: any[] = [];
      journalSnapshot.forEach(doc => {
        journalEntries.push({ id: doc.id, ...doc.data() });
      });

      setSelectedUser({
        ...userData,
        id: userId,
        assessments,
        moods,
        journalEntries,
        stats: {
          totalLogins: Math.floor(Math.random() * 50) + 10,
          avgSessionTime: Math.floor(Math.random() * 30) + 15,
          lastActive: userData.lastLogin,
          engagementScore: Math.floor(Math.random() * 40) + 60
        }
      });

    } catch (error) {
      console.error('Error fetching user details:', error);
      toast({
        title: "Error",
        description: "Failed to load user details",
        variant: "destructive",
      });
    }
  };

  const generateDemoRegistrations = () => {
    const registrations: Record<string, number> = {};
    for (let i = 30; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      const dateKey = date.toISOString().split('T')[0];
      registrations[dateKey] = Math.floor(Math.random() * 15) + 1;
    }
    return registrations;
  };

  const generateDemoUsers = () => {
    const names = ['Alice Johnson', 'Bob Smith', 'Carol Davis', 'David Wilson', 'Emma Brown', 'Frank Miller', 'Grace Lee', 'Henry Taylor'];
    const domains = ['gmail.com', 'yahoo.com', 'outlook.com', 'university.edu'];
    
    return Array.from({ length: 50 }, (_, i) => {
      const name = names[i % names.length];
      const email = `${name.toLowerCase().replace(' ', '.')}@${domains[i % domains.length]}`;
      const lastLogin = new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000);
      const createdAt = new Date(Date.now() - Math.random() * 90 * 24 * 60 * 60 * 1000);
      
      return {
        id: `user_${i + 1}`,
        displayName: name,
        email,
        lastLogin: lastLogin.toISOString(),
        createdAt: createdAt.toISOString(),
        status: Math.random() > 0.3 ? 'active' : 'inactive',
        loginCount: Math.floor(Math.random() * 100) + 5
      };
    });
  };

  const generateDemoUserDetails = (userId: string) => {
    return {
      id: userId,
      displayName: 'Sarah Johnson',
      email: 'sarah.johnson@university.edu',
      createdAt: '2024-01-15T10:30:00Z',
      lastLogin: '2024-01-20T14:22:00Z',
      stats: {
        totalLogins: 42,
        avgSessionTime: 23,
        lastActive: '2024-01-20T14:22:00Z',
        engagementScore: 78
      },
      assessments: [
        {
          id: 'academic-stress',
          score: 65,
          completedAt: '2024-01-18T09:15:00Z',
          level: 'Moderate Stress'
        },
        {
          id: 'mood-wellness',
          score: 82,
          completedAt: '2024-01-16T16:45:00Z',
          level: 'Good'
        }
      ],
      moods: [
        { emoji: '😊', label: 'Happy', createdAt: '2024-01-20T08:30:00Z' },
        { emoji: '😌', label: 'Calm', createdAt: '2024-01-19T12:15:00Z' },
        { emoji: '😰', label: 'Anxious', createdAt: '2024-01-18T14:20:00Z' }
      ],
      journalEntries: [
        { text: 'Today was a good day...', createdAt: '2024-01-20T20:30:00Z' },
        { text: 'Feeling stressed about exams...', createdAt: '2024-01-18T21:15:00Z' }
      ]
    };
  };

  const filteredUsers = usersList.filter(user => {
    const matchesSearch = user.displayName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterStatus === 'all' || user.status === filterStatus;
    return matchesSearch && matchesFilter;
  });

  // User-Level Dashboard Component
  if (selectedUser) {
    return (
      <div className="space-y-8 animate-slide-up-smooth">
        {/* User Header */}
        <div className="relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-400/20 via-purple-400/20 to-pink-400/20 rounded-3xl animate-gradient"></div>
          <div className="relative p-8 glass-modern rounded-3xl border-0">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-6">
                <Button 
                  onClick={() => setSelectedUser(null)}
                  variant="outline"
                  className="rounded-2xl"
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Dashboard
                </Button>
                <div>
                  <h1 className="text-3xl font-bold text-gray-800 mb-2">
                    {selectedUser.displayName || 'Unknown User'}
                  </h1>
                  <p className="text-gray-600">{selectedUser.email}</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <span className="text-sm text-gray-500">
                      Member since: {new Date(selectedUser.createdAt).toLocaleDateString()}
                    </span>
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      selectedUser.status === 'active' 
                        ? 'bg-green-100 text-green-700' 
                        : 'bg-gray-100 text-gray-700'
                    }`}>
                      {selectedUser.status === 'active' ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
              </div>
              <div className="hidden md:block">
                <div className="w-20 h-20 bg-gradient-to-br from-blue-400 to-purple-400 rounded-full flex items-center justify-center">
                  <Users className="w-10 h-10 text-white" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* User Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="card-modern">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center">
                  <Activity className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-800">{selectedUser.stats.totalLogins}</span>
              </div>
              <p className="text-gray-600 font-medium">Total Logins</p>
            </CardContent>
          </Card>

          <Card className="card-modern">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-800">{selectedUser.stats.avgSessionTime}m</span>
              </div>
              <p className="text-gray-600 font-medium">Avg Session Time</p>
            </CardContent>
          </Card>

          <Card className="card-modern">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center">
                  <Target className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-800">{selectedUser.stats.engagementScore}%</span>
              </div>
              <p className="text-gray-600 font-medium">Engagement Score</p>
            </CardContent>
          </Card>

          <Card className="card-modern">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-white" />
                </div>
                <span className="text-2xl font-bold text-gray-800">
                  {selectedUser.lastLogin ? new Date(selectedUser.lastLogin).toLocaleDateString() : 'Never'}
                </span>
              </div>
              <p className="text-gray-600 font-medium">Last Active</p>
            </CardContent>
          </Card>
        </div>

        {/* User Activity Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Assessments */}
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="w-6 h-6 mr-2 text-purple-500" />
                Assessment History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {selectedUser.assessments.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No assessments completed</p>
                ) : (
                  selectedUser.assessments.map((assessment: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-xl">
                      <div>
                        <h4 className="font-medium text-gray-800 capitalize">
                          {assessment.id.replace('-', ' ')}
                        </h4>
                        <p className="text-sm text-gray-600">
                          {new Date(assessment.completedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-gray-800">{assessment.score}%</div>
                        <div className={`text-xs px-2 py-1 rounded-full ${
                          assessment.score >= 75 ? 'bg-green-100 text-green-700' :
                          assessment.score >= 50 ? 'bg-yellow-100 text-yellow-700' :
                          'bg-red-100 text-red-700'
                        }`}>
                          {assessment.level}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Mood Tracking */}
          <Card className="card-modern">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Activity className="w-6 h-6 mr-2 text-green-500" />
                Recent Moods
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {selectedUser.moods.length === 0 ? (
                  <p className="text-gray-500 text-center py-4">No mood entries</p>
                ) : (
                  selectedUser.moods.slice(0, 5).map((mood: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                      <div className="flex items-center space-x-3">
                        <span className="text-2xl">{mood.emoji}</span>
                        <span className="font-medium text-gray-800">{mood.label}</span>
                      </div>
                      <span className="text-sm text-gray-500">
                        {new Date(mood.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Journal Entries */}
        <Card className="card-modern">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="w-6 h-6 mr-2 text-orange-500" />
              Journal Entries
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {selectedUser.journalEntries.length === 0 ? (
                <p className="text-gray-500 text-center py-4">No journal entries</p>
              ) : (
                selectedUser.journalEntries.slice(0, 3).map((entry: any, index: number) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-xl">
                    <p className="text-gray-800 mb-2">{entry.text.substring(0, 150)}...</p>
                    <p className="text-sm text-gray-500">
                      {new Date(entry.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Login Screen
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-full max-w-md glass-modern border-0 shadow-2xl animate-scale-in-smooth">
          <CardHeader className="text-center space-y-4">
            <div className="w-20 h-20 mx-auto bg-gradient-to-br from-red-500 to-orange-500 rounded-3xl flex items-center justify-center animate-float-gentle relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-red-400 to-orange-400 rounded-3xl animate-pulse"></div>
              <div className="relative w-16 h-16 bg-white rounded-2xl flex items-center justify-center">
                <Shield className="w-8 h-8 text-red-500" />
              </div>
              <div className="absolute -top-1 -right-1 w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                <Star className="w-3 h-3 text-white" />
              </div>
            </div>
            
            <CardTitle className="text-3xl font-bold text-gray-800">
              Admin Access Portal
            </CardTitle>
            <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
              Secure access to GoodMind's administrative dashboard and analytics
            </p>
          </CardHeader>
          
          <CardContent className="space-y-6">
            <form onSubmit={handleLogin} className="space-y-4">
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type="email"
                  placeholder="Enter admin email"
                  value={credentials.email}
                  onChange={(e) => setCredentials(prev => ({ ...prev, email: e.target.value }))}
                  className="pl-10 py-6 border-2 focus:border-red-300 dark:focus:border-red-600 rounded-2xl bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm"
                  required
                />
              </div>
              
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="Enter admin password"
                  value={credentials.password}
                  onChange={(e) => setCredentials(prev => ({ ...prev, password: e.target.value }))}
                  className="pl-10 pr-10 py-6 border-2 focus:border-red-300 dark:focus:border-red-600 rounded-2xl bg-white/90 dark:bg-gray-800/90 backdrop-blur-sm"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
              
              <Button
                type="submit"
                disabled={loading}
                className="w-full py-6 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-medium rounded-2xl transform hover:scale-105 transition-all duration-300 shadow-lg hover:shadow-xl relative overflow-hidden"
              >
                {loading ? (
                  <div className="flex items-center justify-center">
                    <div className="loading-spinner h-5 w-5 mr-2"></div>
                    Authenticating...
                  </div>
                ) : (
                  <div className="flex items-center justify-center">
                    <Shield className="w-5 h-5 mr-2" />
                    Access Admin Dashboard
                  </div>
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Loading Screen
  if (!dashboardData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center animate-scale-in-smooth">
          <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-red-500 to-orange-500 rounded-full flex items-center justify-center animate-pulse-soft">
            <BarChart3 className="w-10 h-10 text-white" />
          </div>
          <div className="loading-spinner h-12 w-12 mx-auto mb-4"></div>
          <p className="text-gray-600 text-lg">Loading dashboard analytics...</p>
        </div>
      </div>
    );
  }

  // Main Admin Dashboard
  return (
    <div className="space-y-8 animate-slide-up-smooth">
      {/* Enhanced Header */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-red-400/20 via-orange-400/20 to-purple-400/20 rounded-3xl animate-gradient"></div>
        <div className="relative p-8 glass-modern rounded-3xl border-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold mb-2 animate-fade-in-smooth">
                <span className="text-gray-800">Global Admin Dashboard</span>
                <span className="text-3xl ml-2 animate-float-gentle">🛡️</span>
              </h1>
              <p className="text-gray-600 dark:text-gray-300 text-lg animate-fade-in-smooth" style={{ animationDelay: '0.2s' }}>
                Monitor user engagement, system analytics, and wellness insights across the platform
              </p>
            </div>
            <div className="hidden md:block">
              <div className="w-24 h-24 bg-gradient-to-br from-red-400 to-orange-400 rounded-full flex items-center justify-center animate-pulse-soft">
                <BarChart3 className="w-12 h-12 text-white" />
              </div>
            </div>
          </div>
          <div className="mt-6 flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <Button 
                onClick={fetchDashboardData}
                variant="outline"
                className="rounded-2xl"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh Data
              </Button>
              <Button 
                variant="outline"
                className="rounded-2xl"
              >
                <Download className="w-4 h-4 mr-2" />
                Export Report
              </Button>
            </div>
            <Button 
              onClick={() => setIsAuthenticated(false)}
              variant="outline"
              className="border-red-200 text-red-600 hover:bg-red-50 dark:border-red-800 dark:text-red-400 dark:hover:bg-red-900/20 rounded-2xl"
            >
              <Lock className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>

      {/* Enhanced Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="card-modern hover:shadow-xl transition-all duration-300 group animate-scale-in-smooth">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Users className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-800">{dashboardData.users.total.toLocaleString()}</span>
            </div>
            <p className="text-gray-600 font-medium mb-2">Total Users</p>
            <p className="text-xs text-green-600">+{dashboardData.users.newSignups} new this week</p>
          </CardContent>
        </Card>

        <Card className="card-modern hover:shadow-xl transition-all duration-300 group animate-scale-in-smooth" style={{ animationDelay: '0.1s' }}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-teal-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Activity className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-800">{dashboardData.users.active.toLocaleString()}</span>
            </div>
            <p className="text-gray-600 font-medium mb-2">Active Users</p>
            <p className="text-xs text-gray-500">{dashboardData.trends.engagementRate.toFixed(1)}% engagement rate</p>
          </CardContent>
        </Card>

        <Card className="card-modern hover:shadow-xl transition-all duration-300 group animate-scale-in-smooth" style={{ animationDelay: '0.2s' }}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-indigo-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-800">{dashboardData.assessments.completed.toLocaleString()}</span>
            </div>
            <p className="text-gray-600 font-medium mb-2">Assessments Completed</p>
            <p className="text-xs text-blue-600">{dashboardData.assessments.completionRate.toFixed(1)}% completion rate</p>
          </CardContent>
        </Card>

        <Card className="card-modern hover:shadow-xl transition-all duration-300 group animate-scale-in-smooth" style={{ animationDelay: '0.3s' }}>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform">
                <TrendingUp className="w-6 h-6 text-white" />
              </div>
              <span className="text-2xl font-bold text-gray-800">{dashboardData.assessments.avgScore.toFixed(0)}%</span>
            </div>
            <p className="text-gray-600 font-medium mb-2">Avg Wellness Score</p>
            <p className="text-xs text-gray-500">Platform average</p>
          </CardContent>
        </Card>
      </div>

      {/* Users Table */}
      <Card className="card-modern">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Users className="w-6 h-6 mr-2 text-blue-500" />
              User Management
            </CardTitle>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  placeholder="Search users..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 w-64 rounded-xl"
                />
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="border border-gray-200 rounded-xl px-3 py-2 text-sm"
              >
                <option value="all">All Users</option>
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
              </select>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-3 px-4 font-medium text-gray-600">User</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-600">Email</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-600">Status</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-600">Last Login</th>
                  <th className="text-left py-3 px-4 font-medium text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredUsers.slice(0, 10).map((user) => (
                  <tr key={user.id} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full flex items-center justify-center">
                          <span className="text-white text-sm font-medium">
                            {user.displayName?.charAt(0) || 'U'}
                          </span>
                        </div>
                        <span className="font-medium text-gray-800">{user.displayName || 'Unknown'}</span>
                      </div>
                    </td>
                    <td className="py-3 px-4 text-gray-600">{user.email}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        user.status === 'active' 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {user.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-600">
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never'}
                    </td>
                    <td className="py-3 px-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => fetchUserDetails(user.id)}
                        className="rounded-xl"
                      >
                        <Eye className="w-4 h-4 mr-1" />
                        View Details
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Charts and Analytics */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Assessment Types Distribution */}
        <Card className="card-modern animate-fade-in-smooth" style={{ animationDelay: '0.4s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <PieChart className="w-6 h-6 mr-2 text-purple-500" />
              Assessment Types Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(dashboardData.assessments.types).map(([type, count]) => {
                const percentage = ((count as number) / dashboardData.assessments.completed) * 100;
                return (
                  <div key={type} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700 capitalize">
                      {type.replace('-', ' ')}
                    </span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-purple-500 h-2 rounded-full transition-all duration-1000" 
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{count}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Mood Distribution */}
        <Card className="card-modern animate-fade-in-smooth" style={{ animationDelay: '0.5s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-6 h-6 mr-2 text-green-500" />
              Mood Distribution
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {Object.entries(dashboardData.engagement.moodDistribution).map(([mood, count]) => {
                const percentage = ((count as number) / dashboardData.engagement.moodEntries) * 100;
                const moodColors: Record<string, string> = {
                  'Happy': 'bg-green-500',
                  'Excited': 'bg-yellow-500',
                  'Calm': 'bg-blue-500',
                  'Neutral': 'bg-gray-500',
                  'Anxious': 'bg-orange-500',
                  'Sad': 'bg-purple-500',
                  'Angry': 'bg-red-500'
                };
                return (
                  <div key={mood} className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-700">{mood}</span>
                    <div className="flex items-center space-x-2">
                      <div className="w-24 bg-gray-200 rounded-full h-2">
                        <div 
                          className={`${moodColors[mood] || 'bg-gray-500'} h-2 rounded-full transition-all duration-1000`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                      <span className="text-sm text-gray-600">{count}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Engagement Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="card-modern animate-scale-in-smooth" style={{ animationDelay: '0.6s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <BookOpen className="w-6 h-6 mr-2 text-orange-500" />
              Journal Usage
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-800 mb-2">
                {dashboardData.engagement.journalEntries.toLocaleString()}
              </div>
              <p className="text-gray-600">Total Entries</p>
              <div className="mt-4 text-sm text-gray-500">
                Avg: {(dashboardData.engagement.journalEntries / dashboardData.users.total).toFixed(1)} per user
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-modern animate-scale-in-smooth" style={{ animationDelay: '0.7s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Phone className="w-6 h-6 mr-2 text-blue-500" />
              TARA Sessions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-800 mb-2">
                {dashboardData.engagement.taraSessions.toLocaleString()}
              </div>
              <p className="text-gray-600">Total Sessions</p>
              <div className="mt-4 text-sm text-gray-500">
                AI companion interactions
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-modern animate-scale-in-smooth" style={{ animationDelay: '0.8s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-6 h-6 mr-2 text-green-500" />
              Appointments
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-800 mb-2">
                {dashboardData.engagement.appointments}
              </div>
              <p className="text-gray-600">Booked Appointments</p>
              <div className="mt-4 text-sm text-gray-500">
                Professional consultations
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="card-modern animate-scale-in-smooth" style={{ animationDelay: '0.9s' }}>
          <CardHeader>
            <CardTitle className="flex items-center">
              <TrendingUp className="w-6 h-6 mr-2 text-purple-500" />
              Growth Rate
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-800 mb-2">
                {dashboardData.trends.weeklyGrowth.toFixed(1)}%
              </div>
              <p className="text-gray-600">Weekly Growth</p>
              <div className="mt-4 text-sm text-gray-500">
                User acquisition rate
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* User Registration Trend */}
      <Card className="card-modern animate-fade-in-smooth" style={{ animationDelay: '1s' }}>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-6 h-6 mr-2 text-blue-500" />
            User Registration Trend (Last 30 Days)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-end justify-between space-x-1 p-4">
            {Object.entries(dashboardData.users.registrations)
              .slice(-30)
              .map(([date, count]) => {
                const maxCount = Math.max(...Object.values(dashboardData.users.registrations));
                const height = ((count as number) / maxCount) * 100;
                return (
                  <div key={date} className="flex flex-col items-center group">
                    <div 
                      className="bg-gradient-to-t from-blue-500 to-cyan-400 rounded-t w-3 min-h-[4px] transition-all duration-500 hover:from-blue-600 hover:to-cyan-500"
                      style={{ height: `${height}%` }}
                      title={`${date}: ${count} registrations`}
                    ></div>
                    <span className="text-xs text-gray-500 mt-1 transform rotate-45 origin-left group-hover:text-blue-600 transition-colors">
                      {new Date(date).getDate()}
                    </span>
                  </div>
                );
              })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default AdminPanel;